﻿using BhapticsPopOne.Haptics;
using BigBoxVR;
using Harmony;
using MelonLoader;

namespace BhapticsPopOne
{
    [HarmonyPatch(typeof(PlayerBuff), "OnBuffStateChanged")]
    public class OnBuffStateChanged
    {
        static void Prefix(PlayerBuff __instance, InventorySlot.BuffRecord record, BuffState state)
        {
            if (__instance.container != Mod.Instance.Data.Players.LocalPlayerContainer)
                return;

            if (__instance.model.Info.name == "EnergyDrink")
            {
                PatternManager.DrinkSoda(state);
            } else if (__instance.model.Info.name == "Banana")
            {
                PatternManager.EatBanana(state);
            }
        }
    }
}
