﻿namespace BhapticsPopOne.Haptics
{
    public class EffectLoop
    {
        private bool firstActiveBuff = true;

        private void PlayActiveBuff()
        {
            if (firstActiveBuff && Mod.Instance.Haptics.Player.IsPlaying("ConsumeEnergyDrink"))
                return;
            
            var active = Mod.Instance.Data.Players.LocalPlayerContainer?.playerBuff?.healthOverTimes;

            if (active == null)
                return;
            
            firstActiveBuff = false;

            if (active.Count < 1)
            {
                firstActiveBuff = false;
                Mod.Instance.Haptics.Player.TurnOff("ActiveBuff");
                return;
            }

            if (Mod.Instance.Haptics.Player.IsPlaying("ActiveBuff"))
                return;
            
            Mod.Instance.Haptics.Player.SubmitRegistered("ActiveBuff");
        }
        
        public void FixedUpdate()
        {
            PlayActiveBuff();
        }
    }
}